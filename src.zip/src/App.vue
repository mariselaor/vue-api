<template>
  <h1>Mi app</h1>
  <hr />
  <MiComponente />
</template>

<script setup lang="ts">
import MiComponente from './components/MiComponente.vue'
</script>
<style scoped></style>
