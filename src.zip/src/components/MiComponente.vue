<template>
  <div>
    <h1>PRIMER COMPONENTE</h1>

    <h3>Valor: {{ valorActual }}</h3>

    <button @click="incrementar">Incrementar</button>

    <button @click="decrementar">Decrementar</button>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const valor = ref(0)

const valorActual = computed(() => valor.value)

const incrementar = () => {
  valor.value++
}

const decrementar = () => {
  valor.value--
}
</script>

<style scoped>
h3 {
  color: red;
}
</style>
